#ifndef COMMON_H
#define COMMON_H

typedef long long int64_t;
const int PAGE_SIZE = 4096;
const int BYTE_SIZE = 8;
#endif